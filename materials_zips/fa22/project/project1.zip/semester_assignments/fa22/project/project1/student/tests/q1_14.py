test = {   'name': 'q1_14',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> # Please use a list of integers from 1 to 5\n>>> all(x in range(1, 6) for x in set(scatter_statements))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
