test = {   'name': 'q1_2',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> first = round(p_five_growth.sort(0).column(2).item(0), 8)\n>>> 0.005 <= first <= 0.5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Compute the annual exponential growth rate\n>>> max(p_five_growth.column(2)) < 0.03\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
