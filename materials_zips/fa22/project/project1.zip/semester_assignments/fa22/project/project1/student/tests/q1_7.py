test = {   'name': 'q1_7',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> # Make sure you are using the date range 1950-2020\n>>> poland_since_1950.num_rows\n71', 'hidden': False, 'locked': False},
                                   {   'code': '>>> # Check your column labels and spelling\n'
                                               ">>> all([label in poland_since_1950.labels for label in ['Children per woman', 'Child deaths per 1000 born']])\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
