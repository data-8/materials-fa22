test = {   'name': 'q1_2_1',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> 0.2 < outer_space_r < 0.4\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
