test = {   'name': 'q3_1_5',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> movie_genre_guess >= 1 and movie_genre_guess <= 2\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
