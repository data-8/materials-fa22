test = {   'name': 'q1_2_2',
    'points': [0, 0, 1],
    'suites': [   {   'cases': [   {'code': '>>> phoenix.num_rows == 46021\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(phoenix.labels) == 6\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> phoenix.labels == ('Date', 'tmax', 'tmin', 'prcp', 'Year', 'Month')\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
