test = {   'name': 'q2_3',
    'points': [0],
    'suites': [   {   'cases': [   {   'code': '>>> len(compute_resampled_line(Table().with_columns(\'x\', make_array(0, 1), \'y\', make_array(1, 3)), "x", "y")) == 2\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
