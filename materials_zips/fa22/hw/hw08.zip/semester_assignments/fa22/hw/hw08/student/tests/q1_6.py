test = {   'name': 'q1_6',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> -5 <= diff_lower_bound <= diff_upper_bound <= 20\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
