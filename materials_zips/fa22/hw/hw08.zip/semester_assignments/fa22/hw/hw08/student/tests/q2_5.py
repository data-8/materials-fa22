test = {   'name': 'q2_5',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> 1 <= cutoff_ten_percent <= 3\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
