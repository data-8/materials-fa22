test = {   'name': 'q1_1',
    'points': [2],
    'suites': [{'cases': [{'code': ">>> dollar_bet_on_red('red') == 1\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
