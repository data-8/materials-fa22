test = {   'name': 'q1_3',
    'points': [0],
    'suites': [   {   'cases': [   {   'code': '>>> # If this test isn\'t passing, try running the cells from the top.\n>>> set(["Pocket", "Color", "Winnings: Red"]) == set(ten_bets.labels)\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
