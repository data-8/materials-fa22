test = {   'name': 'q1_8',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> # Make sure your column names are correct\n>>> wheel.labels[3] == "Winnings: Split"\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
