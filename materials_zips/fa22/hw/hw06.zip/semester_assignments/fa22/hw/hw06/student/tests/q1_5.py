test = {   'name': 'q1_5',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> len(all_gains_red) == 10000\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
