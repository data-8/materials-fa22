test = {   'name': 'q2_7',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> # Make sure you are setting coin_option to an int\n>>> type(coin_option) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 1 <= coin_option <= 3\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
