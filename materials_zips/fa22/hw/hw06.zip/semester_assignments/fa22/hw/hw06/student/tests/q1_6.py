test = {   'name': 'q1_6',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> type(loss_more_than_50) == bool\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
