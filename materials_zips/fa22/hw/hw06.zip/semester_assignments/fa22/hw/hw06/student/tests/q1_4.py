test = {   'name': 'q1_4',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> net_gain_red(10000) != net_gain_red(10000)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
