test = {   'name': 'q4_1',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> # The array should have length 2\n>>> len(deck_model_probabilities) == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # The elements in the array should add up to 1.\n>>> sum(deck_model_probabilities) == 1\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
