test = {   'name': 'q1_2',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> # Make sure your column names are correct\n>>> wheel.labels[2] == "Winnings: Red"\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
