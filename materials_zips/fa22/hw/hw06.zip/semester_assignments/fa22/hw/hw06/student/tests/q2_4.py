test = {   'name': 'q2_4',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> # Your probability output should be a value between 0 and 1.\n>>> 0 < lone_winners < 1\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
