test = {   'name': 'q4_1',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> # Hint: shortest is a number between 40 and 50.\n>>> 40 <= shortest <= 50\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Hint: the average is between the shortest and the longest\n>>> shortest <= average <= longest\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
