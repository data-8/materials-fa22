test = {   'name': 'q1_1',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': ">>> import numpy as np\n>>> # It looks like you didn't make an array.\n>>> type(weird_numbers) == np.ndarray\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> len(weird_numbers) == 4\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
