test = {   'name': 'q3_3',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> len(correct_products) == 4\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
