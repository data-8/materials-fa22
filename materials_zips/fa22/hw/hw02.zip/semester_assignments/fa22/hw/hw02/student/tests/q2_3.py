test = {   'name': 'q2_3',
    'points': [0],
    'suites': [   {   'cases': [   {   'code': '>>> # Make sure that you assign index_of_last_element to an index (integer), \n'
                                               '>>> # not the value at that index\n'
                                               '>>> type(index_of_last_element) == int\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
