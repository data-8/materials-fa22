test = {   'name': 'q3_2',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> # products should be an array!\n>>> len(products) == 4\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
