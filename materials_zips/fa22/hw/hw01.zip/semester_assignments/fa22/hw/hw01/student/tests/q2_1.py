test = {   'name': 'q2_1',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> 1 <= characters_q1 <= 5\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
