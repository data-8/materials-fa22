test = {   'name': 'q8_1',
    'points': [1],
    'suites': [{'cases': [{'code': '>>> survey == "data8 is data gr8"\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
