test = {   'name': 'q4_1',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> isinstance(biggest_change, (int, float))\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
