test = {'name': 'q7_7', 'points': [3], 'suites': [{'cases': [{'code': '>>> exams == 2\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
