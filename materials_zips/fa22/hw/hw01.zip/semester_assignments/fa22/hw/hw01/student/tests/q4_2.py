test = {   'name': 'q4_2',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> isinstance(smallest_change_major, (int, float))\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
