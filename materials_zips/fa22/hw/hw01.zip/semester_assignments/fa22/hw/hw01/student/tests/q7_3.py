test = {'name': 'q7_3', 'points': [4], 'suites': [{'cases': [{'code': '>>> regrade == 2\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
