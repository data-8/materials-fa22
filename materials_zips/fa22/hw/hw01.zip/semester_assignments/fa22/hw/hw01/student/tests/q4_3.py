test = {   'name': 'q4_3',
    'points': [0, 0, 0],
    'suites': [   {   'cases': [   {'code': '>>> isinstance(gws_relative_change, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(linguistics_relative_change, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(rhetoric_relative_change, (int, float))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
