test = {   'name': 'q3_9',
    'points': [4],
    'suites': [{'cases': [{'code': '>>> -5 < simulate_one_statistic() < 5\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
