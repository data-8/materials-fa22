test = {   'name': 'q1_4',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> type(valid_test_stat) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> any((valid_test_stat == x for x in np.arange(1,5)))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
