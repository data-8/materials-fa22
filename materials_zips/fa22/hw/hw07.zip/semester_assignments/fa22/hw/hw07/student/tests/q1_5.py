test = {   'name': 'q1_5',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> type(observed_statistic) == float\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0 <= observed_statistic <= 100\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
