test = {   'name': 'q3_10',
    'points': [4],
    'suites': [{'cases': [{'code': '>>> len(simulated_statistics_ab) == 4000\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
