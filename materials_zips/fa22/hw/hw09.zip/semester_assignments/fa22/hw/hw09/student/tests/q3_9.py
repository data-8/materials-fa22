test = {   'name': 'q3_9',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> min_sufficient or not min_sufficient \nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
