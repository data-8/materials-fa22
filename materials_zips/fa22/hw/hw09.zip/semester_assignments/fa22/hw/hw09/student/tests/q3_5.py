test = {   'name': 'q3_5',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> 0.4 <= lower_limit < upper_limit <= 0.7\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
