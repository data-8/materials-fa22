test = {   'name': 'q1_2',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> final_scores.num_columns\n3', 'hidden': False, 'locked': False},
                                   {'code': ">>> set(['Opponent', 'Cal Score', 'Opponent Score']) == set(final_scores.labels)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
