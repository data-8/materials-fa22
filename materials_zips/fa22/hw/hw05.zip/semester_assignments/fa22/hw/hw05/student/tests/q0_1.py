test = {   'name': 'q0_1',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> # Make sure that your answer is a string\n>>> type(secret_phrase) == str \nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
