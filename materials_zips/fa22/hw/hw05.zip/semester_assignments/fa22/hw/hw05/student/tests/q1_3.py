test = {   'name': 'q1_3',
    'points': [0, 2],
    'suites': [   {   'cases': [   {'code': ">>> 'did_cal_lose' in globals()\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> did_cal_lose(final_scores.row(1))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
