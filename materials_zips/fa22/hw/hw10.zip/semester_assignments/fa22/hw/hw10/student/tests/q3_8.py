test = {   'name': 'q3_8',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> len(new_errors) == 1230\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
