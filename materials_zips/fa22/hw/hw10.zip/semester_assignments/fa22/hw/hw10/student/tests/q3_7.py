test = {   'name': 'q3_7',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> type(fit_line(example_table)) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(fit_line(example_table).item(0)) in set([float, np.float32, np.float64])\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
