test = {   'name': 'q3_6',
    'points': [3],
    'suites': [   {   'cases': [   {   'code': ">>> # If you're not passing this test, double check your errors function!\n>>> np.round(outcome_errors.item(0), 2) == -25.25\nTrue",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
