test = {   'name': 'q14',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> print_kth_top_movie_year(4)\nYear number 4 for total gross movie sales was: 2009\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
