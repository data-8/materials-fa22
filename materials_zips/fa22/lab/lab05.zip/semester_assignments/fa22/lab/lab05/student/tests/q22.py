test = {   'name': 'q22',
    'points': None,
    'suites': [{'cases': [{'code': '>>> 8100 <= num_different <= 9100\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
