test = {   'name': 'q523',
    'points': None,
    'suites': [{'cases': [{'code': '>>> round(sum_of_bills, 2) == 1795730.06\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
