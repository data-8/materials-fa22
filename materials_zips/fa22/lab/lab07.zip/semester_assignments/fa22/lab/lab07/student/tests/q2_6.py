test = {   'name': 'q2_6',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(observed_difference, float)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> float(round(observed_difference, 3))\n0.848', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
