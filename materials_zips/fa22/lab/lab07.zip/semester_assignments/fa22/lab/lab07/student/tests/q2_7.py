test = {   'name': 'q2_7',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> np.isclose(round(find_test_stat(bakers, "won", "star baker awards"), 3) - 0.848, 0)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
