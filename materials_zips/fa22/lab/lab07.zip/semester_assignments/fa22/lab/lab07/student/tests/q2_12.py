test = {   'name': 'q2_12',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> # Make sure secret_word is assigned to a string!\n>>> type(secret_word) == str\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> secret_word == "data8 is gr8"\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
