test = {   'name': 'q36',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> berkeley_markets.num_rows == 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> list(berkeley_markets.column('city')) == ['Berkeley', 'Berkeley', 'Berkeley']\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
