test = {   'name': 'q2_1_2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> import hashlib \n'
                                               '>>> def get_hash(num):\n'
                                               '...     """Helper function for assessing correctness."""\n'
                                               '...     return hashlib.md5(str(num).encode()).hexdigest()\n'
                                               '>>> \n'
                                               '>>> get_hash(np.round(probability_large_given_shiny, 3))\n'
                                               "'54fbf38cf649866815e0fefc46a1f6c7'",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
