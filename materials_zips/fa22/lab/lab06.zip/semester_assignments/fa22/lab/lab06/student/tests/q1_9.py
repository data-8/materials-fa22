test = {   'name': 'q1_9',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> 0 <= proportion_greater_or_equal <= 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> proportion_greater_or_equal*1000 == np.count_nonzero(simulated_statistics >= observed_statistic)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
